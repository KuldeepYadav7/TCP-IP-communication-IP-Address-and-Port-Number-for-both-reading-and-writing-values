#include "TCPIPCommunication.hpp"
#include <iostream>

TCPIPCommunication::TCPIPCommunication(boost::asio::io_service& io_service, const std::string& host, int port)
    : socket_(io_service), endpoint_(boost::asio::ip::address::from_string(host), port) {
    socket_.connect(endpoint_);
}

void TCPIPCommunication::read() {
    char data[1024];
    size_t length = socket_.read_some(boost::asio::buffer(data));
    std::cout << "Read: " << std::string(data, length) << std::endl;
}

void TCPIPCommunication::write(const std::string& data) {
    boost::asio::write(socket_, boost::asio::buffer(data));
    std::cout << "Written: " << data << std::endl;
}

#include <iostream>
#include <boost/asio.hpp>
#include <thread>
#include <vector>
#include <memory>
#include <functional>
#include "TCPIPCommunication.hpp"

// Stub function for testing
void test_tcpip_communication() {
    try {
        boost::asio::io_service io_service;
        TCPIPCommunication tcpComm(io_service, "127.0.0.1", 12345);

        tcpComm.write("Hello, Device!");
        tcpComm.read();
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }
}

// Main function
int main() {
    // Simulate multiple device communication
    std::vector<std::thread> device_threads;

    for (int i = 0; i < 5; ++i) {
        device_threads.emplace_back(test_tcpip_communication);
    }

    for (auto& t : device_threads) {
        t.join();
    }

    return 0;
}

#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "TCPIPCommunication.hpp"

TEST_CASE("TCP/IP Communication", "[tcpip]") {
    boost::asio::io_service io_service;
    TCPIPCommunication tcpComm(io_service, "127.0.0.1", 12345);

    REQUIRE_NOTHROW(tcpComm.write("Test message"));
    REQUIRE_NOTHROW(tcpComm.read());
}

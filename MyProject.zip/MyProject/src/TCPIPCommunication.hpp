#ifndef TCPIPCOMMUNICATION_HPP
#define TCPIPCOMMUNICATION_HPP

#include <boost/asio.hpp>
#include <string>

class CommunicationProtocol {
public:
    virtual void read() = 0;
    virtual void write(const std::string& data) = 0;
    virtual ~CommunicationProtocol() = default;
};

class TCPIPCommunication : public CommunicationProtocol {
public:
    TCPIPCommunication(boost::asio::io_service& io_service, const std::string& host, int port);

    void read() override;
    void write(const std::string& data) override;

private:
    boost::asio::ip::tcp::socket socket_;
    boost::asio::ip::tcp::endpoint endpoint_;
};

#endif // TCPIPCOMMUNICATION_HPP
